import Translate from "@/app/components/translate";
export default function Home() {
  return (
    <>
      <Translate />
    </>
  );
}
